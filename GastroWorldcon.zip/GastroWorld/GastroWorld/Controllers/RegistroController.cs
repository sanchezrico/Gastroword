﻿using Microsoft.AspNetCore.Mvc;

namespace GastroWorld.Controllers
{
    public class RegistroController : Controller
    {
        public IActionResult Registro()
        {
            return View();
        }
    }
}
