﻿using Microsoft.AspNetCore.Mvc;

namespace GastroWorld.Controllers
{
    public class ZonasocialController : Controller
    {
        public IActionResult Zonasocial()
        {
            return View();
        }
    }
}
