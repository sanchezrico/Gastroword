﻿namespace GastroWorld.Models
{
    public class ApplicationDbContext
    {
    }
}
